﻿namespace ArcihetechtCaseStudy.DTOS
{
    public class CreateTransferDto
    {
        public int ReceiverId { get; set; }
        public decimal Amount { get; set; }
    }
}
