﻿namespace ArcihetechtCaseStudy.DTOS
{
    public class TopUpDto
    {
        public decimal Amount { get; set; }
    }
}
