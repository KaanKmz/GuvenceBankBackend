﻿namespace ArcihetechtCaseStudy.DTOS
{
    public class UpdateUserDto
    {
        public string Username { get; set; }
        public string Email { get; set; }
        public string? NewPassword { get; set; }  // İsteğe bağlı şifre değişikliği
    }
}
